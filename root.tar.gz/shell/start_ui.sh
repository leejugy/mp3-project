cd /root
flutter-client -b /root/bundle -f &