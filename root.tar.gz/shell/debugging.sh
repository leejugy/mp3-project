cd /root
/root/shell/get_main_app.sh

chmod +x mp3
gdbserver :1234 ./mp3